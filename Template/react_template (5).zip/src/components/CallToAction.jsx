export default function CallToAction({ onSignupClick }) {
  return (
    <section id="cta" className="bg-indigo-700 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Ready to find your perfect accommodation?
          </h2>
          <p className="mt-4 text-xl text-indigo-100">
            Join thousands of satisfied customers who found their ideal living space through Homivo.
          </p>
          <div className="mt-8 flex justify-center">
            <button
              onClick={onSignupClick}
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 transition-colors"
            >
              Sign up now
              <i className="fas fa-arrow-right ml-2"></i>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}